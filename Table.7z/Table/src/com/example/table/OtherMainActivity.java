package com.example.table;

import java.util.ArrayList;




import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class OtherMainActivity extends Activity {

	Tabrow clickedrow;
	boolean clicked=false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_other_main);
		
		
		final ArrayList<Tabrow> tabarr=new ArrayList<Tabrow>();
		
		Tabrow t1=new Tabrow("USD", 0.154, -0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t2=new Tabrow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t3=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t4=new Tabrow("USD", 0.154, -0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t5=new Tabrow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t6=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t7=new Tabrow("USD", 0.154, -0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t8=new Tabrow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t9=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t10=new Tabrow("USD", 0.154, -0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t11=new Tabrow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t12=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t13=new Tabrow("USD", 0.154, -0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t14=new Tabrow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t15=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t16=new Tabrow("USD", 0.154, -0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t17=new Tabrow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t18=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t19=new Tabrow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tabrow t20=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t21=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t22=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t23=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t24=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t25=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t26=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		Tabrow t27=new Tabrow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		
		tabarr.add(t1);
		tabarr.add(t2);
		tabarr.add(t3);
		tabarr.add(t4);
		tabarr.add(t5);
		tabarr.add(t6);
		tabarr.add(t7);
		tabarr.add(t8);
		tabarr.add(t9);
		tabarr.add(t10);
		tabarr.add(t11);
		tabarr.add(t12);
		tabarr.add(t13);
		tabarr.add(t14);
		tabarr.add(t15);
		tabarr.add(t16);
		tabarr.add(t17);
		tabarr.add(t18);
		tabarr.add(t19);
		tabarr.add(t20);
		tabarr.add(t21);
		tabarr.add(t22);
		tabarr.add(t23);
		tabarr.add(t24);
		tabarr.add(t25);
		tabarr.add(t26);
		tabarr.add(t27);
		
				
	
		TableLayout t=(TableLayout) findViewById(R.id.table);
		for(int i=0;i<tabarr.size();i++)
			
		{
			final Tabrow tr=tabarr.get(i);
			 final TableRow tabr=new TableRow(getBaseContext());
			OnClickListener l=new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					clickedrow=tr;
					clicked=true;
					tabr.setBackgroundResource(R.drawable.black);
					
				}
			};
			
			
			tabr.setOnClickListener(l);
			
		     LayoutParams lp = new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);
		     tabr.setLayoutParams(lp);
			tabr.setBackgroundResource(R.drawable.lightgrey);
			tabr.setWeightSum(57);
			
				TextView tv1=Createview(7, tr.cur,"cur");
				tabr.addView(tv1, 0);
				
				
				//LinearLayout.LayoutParams llp2=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv2=Createview(11, tr.pos1,"pos1");
				tabr.addView(tv2,1);
				
				
				//LinearLayout.LayoutParams llp3=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv3=Createview(11, tr.pos2,"pos2");
				
				tabr.addView(tv3,2);
				
				
				//LinearLayout.LayoutParams llp4=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
				TextView tv4=Createview(5, tr.age,"age");
				
				tabr.addView(tv4,3);
				
				
				
				//LinearLayout.LayoutParams llp5=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
				TextView tv5=Createview(5, tr.pnl,"pnl");
				tabr.addView(tv5,4);
				
				//LinearLayout.LayoutParams llp6=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv6=Createview(10, tr.book,"book");
				
				tabr.addView(tv6,5);
				
				//LinearLayout.LayoutParams llp7=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv7=Createview(10, tr.mkt,"mrk");
				
				tabr.addView(tv7,6);
				tabr.setClickable(true);
				tabr.setFocusable(true);
				tabr.setFocusableInTouchMode(true);
				
				t.addView(tabr);
				
			
			
			
			
		}
		
		
        ImageButton pie=(ImageButton) findViewById(R.id.pie);	
        OnClickListener l=new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent i=new Intent(OtherMainActivity.this, SecondActicity.class);
				
				if(clicked){
				i.putExtra("clicked", clickedrow);
				
				clicked=false;
				startActivity(i);
				}
				else
					i.putExtra("clicked", false);	
				startActivity(i);
			}
		};
		pie.setOnClickListener(l);
        
		
		
		
		
		
		
		
		
		
		
		
		

		
		
		
		
		
	}
	
	TextView Createview(int weight,Object txtvalue,String feild){
		
		TextView tv1=new TextView(this);
	   LayoutParams llp1 = new TableRow.LayoutParams(0, LayoutParams.WRAP_CONTENT,weight);
					tv1.setText(txtvalue+"");
					tv1.setLayoutParams(llp1);
						tv1.setBackgroundResource(R.drawable.lightgrey);
						tv1.setGravity(Gravity.CENTER);
						if(feild.equals("pos1")&& (Double)txtvalue<0  )
						tv1.setTextColor(getResources().getColor(R.color.red));
						
						
						if(feild.equals("pos2")&& (Double)txtvalue<0  )
							tv1.setTextColor(getResources().getColor(R.color.red));
							
						
						
						if(feild.equals("pnl")){
							if( (Double)txtvalue<=0  )
							tv1.setBackgroundResource(R.drawable.red);
							else
								tv1.setBackgroundResource(R.drawable.green);
						}
						//tv1.setLayoutParams(llp1);
						
						
						return tv1;
				}
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.other_main, menu);
		return true;
	}

}
