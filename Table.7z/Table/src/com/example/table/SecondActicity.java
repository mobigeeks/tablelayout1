package com.example.table;

import java.io.Serializable;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;

public class SecondActicity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second_acticity);
		Serializable t=(Tabrow) getIntent().getSerializableExtra("clicked");
		TextView txt=(TextView) findViewById(R.id.text);
		if(t instanceof Tabrow){
		Tabrow tb=(Tabrow) t;
		txt.setText(tb.cur);
		}
		else
			txt.setText("nothing clicked");
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.second_acticity, menu);
		return true;
	}

}
